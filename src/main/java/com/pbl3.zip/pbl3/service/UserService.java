package com.pbl3.service;

import com.pbl3.entity.User;
import com.pbl3.dto.SignupRequest;
import com.pbl3.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // Inject thông qua Constructor
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public User registerUser(SignupRequest signupRequest) {
        // Kiểm tra nếu username hoặc email đã tồn tại
        if (userRepository.existsByUsername(signupRequest.getUsername())) {
            throw new RuntimeException("Tên tài khoản đã tồn tại");
        }
        if (userRepository.existsByEmail(signupRequest.getEmail())) {
            throw new RuntimeException("Email đã được sử dụng");
        }

        // Tạo đối tượng User mới
        User user = new User();
        user.setUsername(signupRequest.getUsername());
        user.setEmail(signupRequest.getEmail());
        
        // Mã hóa mật khẩu trước khi lưu
        String encodedPassword = passwordEncoder.encode(signupRequest.getPassword());
        user.setPassword(encodedPassword);

        // Lưu người dùng vào cơ sở dữ liệu
        return userRepository.save(user);
    }
    
}